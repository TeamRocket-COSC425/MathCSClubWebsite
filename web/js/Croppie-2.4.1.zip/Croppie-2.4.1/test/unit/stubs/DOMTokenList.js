DOMTokenList = function DOMTokenList() {
	this.add = function () {
	};
	this.remove = function () {
	};
	this.item = function () {
	};
	this.toggle = function () {
	};
	this.contains = function () {
	};
};

module.exports = DOMTokenList;